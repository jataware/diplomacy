# -*- coding: utf-8 -*-
""" Test pressgloss library. """

# Standard library imports
import unittest

# pressgloss imports
import pressgloss.core as PRESSGLOSS

if __name__ == '__main__':
  unittest.main()
